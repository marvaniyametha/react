import { Route, Routes } from 'react-router-dom'
import Header from './Component/Header/Header'
import AddProduct from './Component/AddProduct/AddProduct'
import Home from './Component/Home/Home'
import Men from './Component/Man/Men'
import ViewProduct from './Component/ViewProduct/ViewProduct'
import EditProduct from './Component/AddProduct/Editproduct'
import SignIn from './Component/authentication/SignIn'
import SignUp from './Component/authentication/SignUp'

function App() {

  return (
    <>
    <Header/>
    
     <Routes>
      <Route path='/' element={<Home/>}/>
    
      <Route path='/signin' element={<SignIn/>}/> 
      <Route path='/signup' element={<SignUp/>}/> 

      <Route path='/men' element={<Men/>}/>
      <Route path='/addproduct' element={<AddProduct/>}/>
      <Route path='/product-info/:id/:catagory' element={<ViewProduct/>}/>
      <Route path='/home' element={"Progress"}/>
      <Route path='/edit-product/:id' element={<EditProduct/>}/>
     </Routes>
    </>
  )
}

export default App
