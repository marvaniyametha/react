import React, { useEffect, useState } from "react";
import {
  Form,
  Button,
  Row,
  Col,
  Container,
  Card,
  Spinner,
} from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import generateUniqueId from "generate-unique-id";
import { useNavigate } from "react-router-dom";
import { addproductAsync } from "../Services/Action/addProductAction";

const AddProduct = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { isLoading, isCreated, errMSG } = useSelector(
    (state) => state.AddProductRedux
  );
  const { user } = useSelector((state) => state.userReducer);

  const initialState = {
    title: "",
    category: "",
    subcategory: "",
    brand: "",
    price: "",
    discount: "",
    stock: "",
    description: "",
    image: [],
    imageInput: "",
    rates: {
      rating: "",
      rests: "",
    },
  };

  const [inputform, setinputform] = useState(initialState);
  const [inputErr, setinputErr] = useState({});

  /* ================= INPUT CHANGE ================= */
  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "rating" || name === "rests") {
      setinputform({
        ...inputform,
        rates: { ...inputform.rates, [name]: value },
      });
    } else {
      setinputform({ ...inputform, [name]: value });
    }
  };

  /* ================= IMAGE ADD ================= */
  const addImage = () => {
    if (!inputform.imageInput.trim()) return;

    setinputform({
      ...inputform,
      image: [...inputform.image, inputform.imageInput],
      imageInput: "",
    });
  };

  const deleteImage = (index) => {
    setinputform({
      ...inputform,
      image: inputform.image.filter((_, i) => i !== index),
    });
  };

  /* ================= VALIDATION ================= */
  const handleErrors = () => {
    const errors = {};

    if (!inputform.title.trim()) errors.titleErr = "Enter product name";
    if (!inputform.category) errors.categoryErr = "Select category";
    if (!inputform.subcategory) errors.subcategoryErr = "Select subcategory";
    if (!inputform.brand) errors.brandErr = "Select brand";
    if (inputform.price <= 0) errors.priceErr = "Invalid price";
    if (inputform.stock <= 0) errors.stockErr = "Invalid stock";
    if (inputform.discount < 0) errors.discountErr = "Invalid discount";
    if (!inputform.image.length) errors.imageErr = "Add at least one image";
    if (!inputform.description.trim())
      errors.descriptionErr = "Add description";
    if (!inputform.rates.rating) errors.ratingErr = "Enter rating";
    if (!inputform.rates.rests) errors.restsErr = "Enter reviews";

    setinputErr(errors);
    return Object.keys(errors).length === 0;
  };

  /* ================= SUBMIT ================= */
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!handleErrors()) return;

    const payload = {
      ...inputform,
      id:
        "PR" +
        generateUniqueId({
          length: 10,
          useLetters: false,
        }),
    };

    dispatch(addproductAsync(payload));
  };

  /* ================= EFFECTS ================= */
  useEffect(() => {
    if (isCreated) {
      setinputform(initialState);
      navigate(`/${inputform.category || ""}`);
    }
  }, [isCreated]);

  useEffect(() => {
    if (!user) navigate("/");
  }, [user]);

  /* ================= OPTIONS ================= */
  const getBrandOptions = () => {
    if (inputform.category === "men")
      return ["Louis Philippe", "Allen Solly", "Park Avenue"];
    if (inputform.category === "women") return ["Zara", "H&M"];
    if (inputform.category === "kids") return ["Gap Kids", "Carter's"];
    return [];
  };

  const getSubCategory = () => {
    if (inputform.category === "men") return ["Jeans", "T-Shirt"];
    if (inputform.category === "women") return ["Top", "Saree"];
    if (inputform.category === "kids") return ["Shirt", "Frock"];
    return [];
  };

  /* ================= UI ================= */
  return (
    <Container
      fluid
      style={{
        minHeight: "100vh",
        backgroundColor: "#0f1115",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        color: "#fff",
      }}
    >
      {isLoading ? (
        <Spinner />
      ) : (
        <Card
          style={{
            width: "100%",
            maxWidth: "750px",
            backgroundColor: "#161a22",
            border: "1px solid #222",
          }}
        >
          <Card.Body>
            <h4 className="text-center mb-4">Add New Product</h4>

            {errMSG && (
              <p className="text-danger text-center">{errMSG}</p>
            )}

            <Form onSubmit={handleSubmit}>
              <Row>
                <Col md={6}>
                  <Form.Control
                    placeholder="Title"
                    name="title"
                    value={inputform.title}
                    onChange={handleChange}
                    className="mb-2"
                  />
                  <small className="text-danger">{inputErr.titleErr}</small>
                </Col>

                <Col md={6}>
                  <Form.Select
                    name="category"
                    value={inputform.category}
                    onChange={handleChange}
                    className="mb-2"
                  >
                    <option value="">Category</option>
                    <option value="men">Men</option>
                    <option value="women">Women</option>
                    <option value="kids">Kids</option>
                  </Form.Select>
                  <small className="text-danger">{inputErr.categoryErr}</small>
                </Col>
              </Row>

              {inputform.category && (
                <Row>
                  <Col md={6}>
                    <Form.Select
                      name="subcategory"
                      value={inputform.subcategory}
                      onChange={handleChange}
                      className="mb-2"
                    >
                      <option value="">Subcategory</option>
                      {getSubCategory().map((s, i) => (
                        <option key={i}>{s}</option>
                      ))}
                    </Form.Select>
                  </Col>

                  <Col md={6}>
                    <Form.Select
                      name="brand"
                      value={inputform.brand}
                      onChange={handleChange}
                      className="mb-2"
                    >
                      <option value="">Brand</option>
                      {getBrandOptions().map((b, i) => (
                        <option key={i}>{b}</option>
                      ))}
                    </Form.Select>
                  </Col>
                </Row>
              )}

              <Row>
                <Col md={4}>
                  <Form.Control
                    type="number"
                    placeholder="Price"
                    name="price"
                    value={inputform.price}
                    onChange={handleChange}
                    className="mb-2"
                  />
                </Col>
                <Col md={4}>
                  <Form.Control
                    type="number"
                    placeholder="Stock"
                    name="stock"
                    value={inputform.stock}
                    onChange={handleChange}
                    className="mb-2"
                  />
                </Col>
                <Col md={4}>
                  <Form.Control
                    type="number"
                    placeholder="Discount %"
                    name="discount"
                    value={inputform.discount}
                    onChange={handleChange}
                    className="mb-2"
                  />
                </Col>
              </Row>

              {/* IMAGE */}
              <Row>
                <Col md={9}>
                  <Form.Control
                    placeholder="Image URL"
                    name="imageInput"
                    value={inputform.imageInput}
                    onChange={handleChange}
                  />
                </Col>
                <Col md={3}>
                  <Button
                    onClick={addImage}
                    style={{ width: "100%" }}
                  >
                    Add Image
                  </Button>
                </Col>
              </Row>

              <div className="d-flex mt-2">
                {inputform.image.map((img, i) => (
                  <div key={i} style={{ position: "relative", marginRight: 10 }}>
                    <img
                      src={img}
                      alt=""
                      width={60}
                      height={60}
                      style={{ objectFit: "contain", border: "1px solid #333" }}
                    />
                    <Button
                      size="sm"
                      variant="danger"
                      onClick={() => deleteImage(i)}
                      style={{
                        position: "absolute",
                        top: -5,
                        right: -5,
                        padding: "0 5px",
                      }}
                    >
                      ×
                    </Button>
                  </div>
                ))}
              </div>

              <Form.Control
                as="textarea"
                rows={3}
                name="description"
                placeholder="Description"
                value={inputform.description}
                onChange={handleChange}
                className="mt-3"
              />

              <Button
                type="submit"
                className="mt-4 w-100"
                style={{
                  backgroundColor: "#4a6cf7",
                  border: "none",
                }}
              >
                Add Product
              </Button>
            </Form>
          </Card.Body>
        </Card>
      )}
    </Container>
  );
};

export default AddProduct;
