import React, { useEffect, useState } from "react";
import { Container, Row, Col, Card, Button, Form, Carousel, Spinner } from "react-bootstrap";
import { AiOutlineHeart, AiFillStar } from "react-icons/ai";
import { FiTruck } from "react-icons/fi";
import { HiOutlineShoppingBag } from "react-icons/hi";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { CiEdit } from "react-icons/ci";
import { LiaTrashRestoreSolid } from "react-icons/lia";
import { deleteproductAsync, getallproductAync } from "../Services/Action/addProductAction";
import "./ViewProduct.css";

const ViewProduct = () => {
  const [ingindex, setingindex] = useState(0);
  const [current, setCurrent] = useState(0);
  const [selectedSize, setSelectedSize] = useState(null);
  const [pincode, setPincode] = useState("");

  const { filterproduct, isLoding } = useSelector((state) => state);
  const { id, catagory } = useParams();
  const dispatch = useDispatch();
  const naviget = useNavigate();
  const product = filterproduct.find((product) => product.id == id);

  useEffect(() => {
    dispatch(getallproductAync(catagory));
  }, []);

  if (!product) return <p className="p-5">Product Not Found</p>;

  const handalimage = (index) => {
    setingindex(index);
  };

  const handalDelete = (id) => {
    dispatch(deleteproductAsync(id));
    if (product.category == "men") {
      naviget('/men');
    } else if (product.category == "women") {
      naviget('/women');
    } else {
      naviget('/kids');
    }
  };

  const handalEdit = (id) => {
    naviget(`/edit-product/${id}`);
  };

  const handleSizeSelect = (size) => {
    setSelectedSize(size);
  };

  const handlePincodeCheck = () => {
    if (pincode.length === 6) {
      alert(`Delivery available for pincode: ${pincode}`);
    } else {
      alert("Please enter a valid 6-digit pincode");
    }
  };

  // Age group sizes for kids category
  const kidsSizes = ["3-4Y", "4-5Y", "5-6Y", "7-8Y", "9-10Y", "11-12Y", "13-14Y"];
  const adultSizes = ["S", "M", "L", "XL", "XXL"];

  const sizesToUse = catagory === "kids" ? kidsSizes : adultSizes;

  return (
    <Container fluid className="mt-4 view-product-container">
      {isLoding ? (
        <div className="loading-spinner">
          <Spinner animation="border" variant="danger" />
        </div>
      ) : (
        <Row className="mt-3">
          {/* Desktop Image Gallery */}
          <Col md={6} className="d-none d-md-block">
            <Row>
              <Col md={2}>
                <Row className="flex-column image-gallery-container">
                  {product.image.map((img, index) => (
                    <Col md={12} key={index} className="mb-3" onMouseEnter={() => handalimage(index)} style={{ cursor: "pointer" }}>
                      <Card className={`shadow-sm border-0 image-thumbnail-card ${ingindex === index ? 'active' : ''}`}>
                        <Card.Img
                          src={img}
                          style={{
                            width: "100px",
                            height: "100px",
                            objectFit: "cover",
                            objectPosition: "center",
                            borderRadius: "4px",
                          }}
                        />
                      </Card>
                    </Col>
                  ))}
                </Row>
              </Col>

              {/* Main Image */}
              <Col md={8} className="text-center mx-3">
                <img
                  src={product.image[ingindex]}
                  alt={product.title}
                  className="w-100 main-product-image"
                  style={{
                    height: "500px",
                    width: "100%",
                    objectFit: "cover",
                    objectPosition: "center",
                    borderRadius: "4px",
                  }}
                />
              </Col>
            </Row>
          </Col>

          {/* Mobile Carousel */}
          <Col xs={12} className="d-block d-md-none">
            <Carousel
              activeIndex={current}
              onSelect={(selectedIndex) => setCurrent(selectedIndex)}
              interval={3000}
              pause={false}
              controls={false}
              indicators={false}
            >
              {product.image.map((img, index) => (
                <Carousel.Item key={index}>
                  <img
                    src={img}
                    alt={`${product.title} - slide ${index + 1}`}
                    className="d-block w-100 main-product-image"
                    style={{
                      height: "420px",
                      objectFit: "cover",
                      borderRadius: "4px"
                    }}
                  />
                </Carousel.Item>
              ))}
            </Carousel>

            <div className="d-flex justify-content-center mt-3 gap-2">
              {product.image.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  className={`btn btn-sm rounded-circle p-0 carousel-indicator-btn ${i === current ? "active" : ""}`}
                  style={{ width: "8px", height: "8px" }}
                  onClick={() => setCurrent(i)}
                />
              ))}
            </div>
          </Col>

          {/* Product Details */}
          <Col md={6} className="product-details-section">
            {/* Brand and Title */}
            <div className="brand-section">
              <h3 className="product-brand-name">{product.brand || "Kids Ville"}</h3>
              <h5 className="product-title">{product.title || "Boys Spiderman Printed Round Neck Regular Fit Pure Cotton T-Shirt"}</h5>
            </div>

            {/* Ratings */}
            <div className="ratings-section mb-3">
              <span className="rating-badge">
                <AiFillStar className="rating-star" />
                <span className="rating-value">4.9</span>
              </span>
              <span className="rating-separator">|</span>
              <span className="rating-count">1.5k Ratings</span>
            </div>

            {/* Description */}
            {product.description && (
              <p className="product-description mb-4">{product.description}</p>
            )}

            {/* Price Section */}
            <div className="price-section mb-4">
              <h4 className="discounted-price">
                ₹{Math.floor(
                  Number(product.price) -
                  (Number(product.price) * Number(product.discount || 19)) / 100
                )}
              </h4>
              <div className="price-details">
                <span className="original-price">
                  MRP ₹{product.price || "999"}
                </span>
                <span className="discount-percentage">
                  ({product.discount || 19}% OFF)
                </span>
              </div>
              <small className="tax-text">inclusive of all taxes</small>
            </div>

            {/* Size Selector */}
            <div className="size-section mb-4">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h6 className="size-selector-title">
                  SELECT SIZE {catagory === "kids" ? "(Age Group)" : ""}
                </h6>
                <button className="size-chart-btn">SIZE CHART &gt;</button>
              </div>
              <div className="d-flex gap-2 flex-wrap">
                {sizesToUse.map((size) => (
                  <Button
                    key={size}
                    variant="outline-dark"
                    className={`size-button ${selectedSize === size ? 'selected' : ''}`}
                    onClick={() => handleSizeSelect(size)}
                  >
                    {size}
                  </Button>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="action-buttons mb-4">
              <Button
                variant="danger"
                className="add-to-bag-btn"
              >
                <HiOutlineShoppingBag size={20} className="me-2" />
                ADD TO BAG
              </Button>
              <Button
                variant="outline-dark"
                className="wishlist-btn"
              >
                <AiOutlineHeart size={20} className="me-2" />
                WISHLIST
              </Button>
            </div>

            {/* Original Delete/Edit Buttons (Optional - can be hidden or kept) */}
            <div className="admin-buttons d-flex gap-3 mb-4">
              <Button
                variant="danger"
                className="delete-button"
                onClick={() => handalDelete(product.id)}
              >
                <LiaTrashRestoreSolid size={20} className="me-2" />
                DELETE
              </Button>
              <Button
                variant="outline-dark"
                className="edit-button"
                onClick={() => handalEdit(product.id)}
              >
                <CiEdit size={20} className="me-2" />
                EDIT
              </Button>
            </div>

            {/* Delivery Options */}
            <div className="delivery-section mt-4">
              <h6 className="delivery-title">
                DELIVERY OPTIONS <FiTruck className="ms-2" />
              </h6>
              <div className="delivery-input-container mt-2">
                <Form.Control
                  placeholder="Enter pincode"
                  className="delivery-input"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  maxLength={6}
                />
                <Button
                  variant=""
                  className="check-pincode-btn"
                  onClick={handlePincodeCheck}
                >
                  CHECK
                </Button>
              </div>
              <small className="delivery-info-text">
                Please enter PIN code to check delivery time & Pay on Delivery Availability
              </small>
            </div>

            {/* Product Assurance */}
            <div className="assurance-section mt-4">
              <h6 className="assurance-title">100% ORIGINAL PRODUCTS</h6>
              <p className="assurance-text">
                Fast delivery options available depending on your pincode.
              </p>
            </div>
          </Col>
        </Row>
      )}
    </Container>
  );
};

export default ViewProduct;