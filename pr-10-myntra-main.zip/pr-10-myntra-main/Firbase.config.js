import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth"; 

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCXUBtjXpzGeNzhW8IMpsGMJbJuZD3Mgi0",
  authDomain: "mayntra-clone.firebaseapp.com",
  projectId: "mayntra-clone",
  storageBucket: "mayntra-clone.firebasestorage.app",
  messagingSenderId: "923588988100",
  appId: "1:923588988100:web:f2a2c03f713c65bd210d91"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);