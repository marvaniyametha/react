// Import the functions you need from the SDKs you need
import { getAuth } from "@firebase/auth";
import { getFirestore } from "@firebase/firestore";
import { initializeApp } from "firebase/app";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCX0Uns9_3B-LU5-k36yMRkCTbc5yWZNOw",
  authDomain: "megamart-a2594.firebaseapp.com",
  projectId: "megamart-a2594",
  storageBucket: "megamart-a2594.firebasestorage.app",
  messagingSenderId: "1040746230270",
  appId: "1:1040746230270:web:847ee0a87112748ee250af"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);

